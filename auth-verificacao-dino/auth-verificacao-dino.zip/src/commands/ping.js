// Importa o construtor de comandos de barra do discord.js
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    // 'data' define as informações do comando para a API do Discord
    data: new SlashCommandBuilder()
        .setName('ping') // Nome do comando (deve ser em minúsculas, sem espaços)
        .setDescription('Responde com Pong! e a latência do bot.'), // Descrição do comando

    // 'execute' contém a lógica que o comando irá rodar
    async execute(interaction) {
        // 'interaction' representa o comando que foi enviado pelo usuário
        const sent = await interaction.reply({ content: 'Calculando...', fetchReply: true });
        
        // Calcula a latência de ida e volta da mensagem
        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        
        // Calcula a latência da API do Discord
        const apiLatency = Math.round(interaction.client.ws.ping);

        // Edita a resposta original com as informações de latência
        await interaction.editReply(`Pong! 🏓\nLatência da mensagem: ${latency}ms.\nLatência da API: ${apiLatency}ms.`);
    },
};
